import { NextRequest, NextResponse } from 'next/server';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export async function GET(request: NextRequest) {
  const hours = request.nextUrl.searchParams.get('hours') || '24';
  try {
    const res = await fetch(`${API_URL}/api/history?hours=${hours}`, { cache: 'no-store' });
    if (!res.ok) {
      return NextResponse.json({ count: 0, hours: Number(hours), data: [] }, { status: res.status });
    }
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json({ count: 0, hours: Number(hours), data: [] }, { status: 502 });
  }
}
