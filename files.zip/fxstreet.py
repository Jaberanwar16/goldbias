"""
Scraper FXStreet pour les articles Gold et Dollar

NOTE IMPORTANTE:
Les sites comme FXStreet changent regulierement leur structure HTML et
peuvent bloquer le scraping automatise (Cloudflare, rate limiting, etc.).
Les selecteurs CSS ci-dessous sont volontairement larges/generiques ;
si FXStreet change son HTML, ajuste `_extract_article` en inspectant
le DOM reel (F12 -> Elements) et en adaptant les selecteurs.
Verifie toujours les CGU du site avant de scraper en production.
"""

import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from loguru import logger

from config import settings


class FXStreetScraper:
    """Scraper des actualites FXStreet"""

    def __init__(self) -> None:
        self.base_url = settings.fxstreet_base_url
        self.session = requests.Session()
        try:
            self.ua = UserAgent()
            user_agent = self.ua.random
        except Exception:
            user_agent = (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            )
        self.session.headers.update(
            {
                "User-Agent": user_agent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
            }
        )

    def get_gold_articles(self, hours_back: int = 6) -> List[Dict]:
        """Recupere les articles sur l'or"""
        urls = [
            f"{self.base_url}/markets/commodities/gold",
            f"{self.base_url}/technical-analysis/commodities/gold",
        ]
        return self._scrape_and_filter(urls, "gold", hours_back)

    def get_dollar_articles(self, hours_back: int = 6) -> List[Dict]:
        """Recupere les articles sur le dollar"""
        urls = [
            f"{self.base_url}/markets/currencies/us-dollar",
            f"{self.base_url}/technical-analysis/currencies/us-dollar",
        ]
        return self._scrape_and_filter(urls, "dollar", hours_back)

    def _scrape_and_filter(self, urls: List[str], category: str, hours_back: int) -> List[Dict]:
        articles: List[Dict] = []
        for url in urls:
            try:
                articles.extend(self._scrape_url(url, category))
                time.sleep(2)  # Politesse envers le serveur
            except Exception as e:
                logger.warning(f"Erreur scraping {url}: {e}")

        cutoff = datetime.utcnow() - timedelta(hours=hours_back)
        # Ne filtre que les articles dont on a pu determiner une date fiable
        result = []
        for a in articles:
            try:
                if a["published_at"] >= cutoff.isoformat():
                    result.append(a)
            except Exception:
                result.append(a)
        return result

    def _scrape_url(self, url: str, category: str) -> List[Dict]:
        """Scrape une URL specifique"""
        articles: List[Dict] = []
        try:
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")

            article_elements = []
            article_elements.extend(soup.select("article"))
            article_elements.extend(soup.select("[class*='article']"))
            article_elements.extend(soup.select("div[class*='news']"))

            seen = set()
            for element in article_elements:
                if id(element) in seen:
                    continue
                seen.add(id(element))
                article = self._extract_article(element, category, url)
                if article:
                    articles.append(article)
                if len(articles) >= 10:
                    break

        except Exception as e:
            logger.error(f"Erreur scraping {url}: {e}")

        return articles

    def _extract_article(self, element, category: str, source_url: str) -> Optional[Dict]:
        """Extrait les donnees d'un article a partir d'un element HTML"""
        try:
            title_elem = element.select_one("h1, h2, h3, h4, [class*='title'], [class*='headline']")
            if not title_elem:
                return None

            title = title_elem.get_text(strip=True)
            if not title or len(title) < 10:
                return None

            link_elem = element.select_one("a[href]")
            link = link_elem["href"] if link_elem else source_url
            if link.startswith("/"):
                link = self.base_url + link

            summary_elem = element.select_one("p")
            content = summary_elem.get_text(strip=True) if summary_elem else ""

            return {
                "url": link,
                "title": title,
                "content": content,
                "category": category,
                "published_at": datetime.utcnow().isoformat(),
            }
        except Exception as e:
            logger.debug(f"Impossible d'extraire un article: {e}")
            return None

    def get_all_recent_articles(self, hours_back: int = 6) -> List[Dict]:
        """Recupere tous les articles recents (gold + dollar), dedupliques"""
        gold_articles = self.get_gold_articles(hours_back)
        dollar_articles = self.get_dollar_articles(hours_back)

        all_articles = gold_articles + dollar_articles

        seen_titles = set()
        unique_articles = []
        for article in all_articles:
            title_lower = article["title"].lower()
            if title_lower not in seen_titles:
                seen_titles.add(title_lower)
                unique_articles.append(article)

        logger.info(
            f"Recupere {len(unique_articles)} articles uniques "
            f"({len(gold_articles)} gold, {len(dollar_articles)} dollar)"
        )
        return unique_articles[: settings.max_articles_per_scrape]


scraper = FXStreetScraper()
