"""
Analyse de sentiment via IA (Claude ou GPT)
"""

import json
import re
from datetime import datetime
from typing import Dict, List, Optional

from loguru import logger

from config import settings


class SentimentAnalyzer:
    """Analyse le sentiment des articles via IA"""

    def __init__(self) -> None:
        self.provider = settings.ai_provider
        self.model = settings.ai_model
        self.client = None
        self._init_client()

    def _init_client(self) -> None:
        if self.provider == "anthropic" and settings.anthropic_api_key:
            try:
                import anthropic

                self.client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
                logger.info("Client Anthropic initialise")
            except Exception as e:
                logger.error(f"Erreur init Anthropic: {e}")
        elif self.provider == "openai" and settings.openai_api_key:
            try:
                from openai import OpenAI

                self.client = OpenAI(api_key=settings.openai_api_key)
                logger.info("Client OpenAI initialise")
            except Exception as e:
                logger.error(f"Erreur init OpenAI: {e}")
        else:
            logger.warning("Aucune cle API IA configuree - le mode fallback sera utilise")

    def analyze(self, articles: List[Dict]) -> Optional[Dict]:
        """Analyse le sentiment des articles. Retourne toujours un dict (fallback si l'IA echoue)."""
        if not articles:
            logger.warning("Aucun article a analyser")
            return None

        if not self.client:
            return self._fallback_analysis(articles)

        prompt = self._build_prompt(articles)

        try:
            raw_result = (
                self._call_anthropic(prompt)
                if self.provider == "anthropic"
                else self._call_openai(prompt)
            )
            analysis = json.loads(self._extract_json(raw_result))
            analysis["timestamp"] = datetime.utcnow().isoformat()
            analysis["articles_analyzed"] = len(articles)
            return analysis

        except json.JSONDecodeError as e:
            logger.error(f"Erreur parsing JSON de la reponse IA: {e}")
            return self._fallback_analysis(articles)
        except Exception as e:
            logger.error(f"Erreur analyse IA: {e}")
            return self._fallback_analysis(articles)

    @staticmethod
    def _extract_json(text: str) -> str:
        """Extrait le premier bloc JSON valide d'une reponse texte (au cas ou le modele ajoute du texte autour)."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        return match.group(0) if match else text

    def _build_prompt(self, articles: List[Dict]) -> str:
        articles_text = ""
        for i, article in enumerate(articles[:15], 1):
            articles_text += f"\nArticle {i}:\n"
            articles_text += f"Titre: {article['title']}\n"
            if article.get("content"):
                articles_text += f"Extrait: {article['content'][:400]}\n"
            articles_text += f"Categorie: {article['category']}\n"
            articles_text += "-" * 40 + "\n"

        return f"""Tu es un analyste macroeconomique expert specialise dans l'or (XAUUSD) et le dollar americain (USD/DXY).

Analyse ces articles recents et produis une analyse de sentiment structuree.

Articles a analyser :
{articles_text}

Regles importantes :
- Sois concis et precis
- Base-toi uniquement sur les articles fournis
- Le sentiment doit refleter les tendances recentes
- Les key_drivers doivent etre des facteurs macroeconomiques concrets
- Le score de confiance reflete la clarte du signal (0 = pas clair, 100 = tres clair)

Reponds UNIQUEMENT avec un JSON valide (pas de texte avant/apres) au format exact suivant :

{{
    "gold": {{
        "bias": "Bullish|Bearish|Neutral",
        "confidence": 0,
        "summary": "Phrase courte (max 20 mots)",
        "key_drivers": ["driver1", "driver2", "driver3"]
    }},
    "dollar": {{
        "bias": "Bullish|Bearish|Neutral",
        "confidence": 0,
        "summary": "Phrase courte (max 20 mots)",
        "key_drivers": ["driver1", "driver2", "driver3"]
    }},
    "overall_comment": "Commentaire macro de 1-2 phrases sur la relation or/dollar",
    "correlation": "positive|negative|neutral",
    "market_context": "Contexte de marche en 1 phrase"
}}
"""

    def _call_anthropic(self, prompt: str) -> str:
        message = self.client.messages.create(
            model=self.model,
            max_tokens=settings.max_tokens,
            temperature=settings.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text

    def _call_openai(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "Tu es un analyste macroeconomique. Reponds uniquement en JSON."},
                {"role": "user", "content": prompt},
            ],
            temperature=settings.temperature,
            max_tokens=settings.max_tokens,
        )
        return response.choices[0].message.content

    def _fallback_analysis(self, articles: List[Dict]) -> Dict:
        """Analyse de secours (comptage de mots-cles) si l'IA n'est pas disponible ou echoue"""
        gold_bullish = gold_bearish = dollar_bullish = dollar_bearish = 0

        bullish_terms = ["rally", "surge", "gain", "rise", "bullish", "strong", "support", "buy", "uptrend"]
        bearish_terms = ["decline", "drop", "fall", "bearish", "weak", "resistance", "sell", "downtrend", "loss"]

        for article in articles:
            text = f"{article.get('title', '')} {article.get('content', '')}".lower()
            is_bullish = any(term in text for term in bullish_terms)
            is_bearish = any(term in text for term in bearish_terms)

            if article.get("category") == "gold":
                gold_bullish += int(is_bullish)
                gold_bearish += int(is_bearish)
            else:
                dollar_bullish += int(is_bullish)
                dollar_bearish += int(is_bearish)

        def determine_bias(bullish: int, bearish: int):
            total = bullish + bearish
            if total == 0:
                return "Neutral", 40
            if bullish > bearish * 1.5:
                return "Bullish", min(int(bullish / total * 100), 70)
            if bearish > bullish * 1.5:
                return "Bearish", min(int(bearish / total * 100), 70)
            return "Neutral", 50

        gold_bias, gold_conf = determine_bias(gold_bullish, gold_bearish)
        dollar_bias, dollar_conf = determine_bias(dollar_bullish, dollar_bearish)

        return {
            "gold": {
                "bias": gold_bias,
                "confidence": gold_conf,
                "summary": f"Analyse de secours basee sur {len(articles)} articles (mots-cles)",
                "key_drivers": ["Analyse automatique (fallback, sans IA)"],
            },
            "dollar": {
                "bias": dollar_bias,
                "confidence": dollar_conf,
                "summary": f"Analyse de secours basee sur {len(articles)} articles (mots-cles)",
                "key_drivers": ["Analyse automatique (fallback, sans IA)"],
            },
            "overall_comment": "Analyse basee sur un comptage de termes cles (aucune cle API IA configuree ou echec de l'IA).",
            "timestamp": datetime.utcnow().isoformat(),
            "articles_analyzed": len(articles),
        }


analyzer = SentimentAnalyzer()
